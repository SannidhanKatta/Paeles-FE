import { createContext } from "react";

export const AdminContext = createContext();
export const adminProvider = ({ children }) => {
  return <></>;
};
